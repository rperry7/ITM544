ITMO 544 Lab 06 - Graduate Python Source Code

This folder includes the four Python infrastructure create/delete scripts,
stack/ package, Weather and Advisor Node.js services, pytest tests, and
Python smoke test. The live AWS infrastructure has already been cleaned up.

The .env.example file is a NON-SECRET template. The original local .env,
credentials, backups, Python virtual environment and previous lab artifacts
are deliberately excluded. There is no need to redeploy to submit the work.

Unit tests: python -m pytest -m "not integration and not chaos"
Integration and chaos tests need a live AWS stack and are NOT to be rerun
just to prepare the submission. See separate screenshots for results.
