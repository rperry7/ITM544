"""Remove weather and advisor stack resources (leave DB and Gemini SSM key)."""
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients
from stack.weather_lab_stack import delete_weather_stack

if __name__ == '__main__':
    cfg=WeatherSettings.from_file()
    print('Deleting two-tier web stack and EC2 instances...',flush=True)
    delete_weather_stack(aws_clients(cfg.region, cfg.values.get("AWS_PROFILE")),cfg)
    print('Stack deleted. NEXT: python delete_database.py')
