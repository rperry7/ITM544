"""Graduate Step 8: break Gemini with boto3, observe fallback, restore key safely."""
import time
import requests
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients


def main():
    cfg=WeatherSettings.from_file();aws=aws_clients(cfg.region, cfg.values.get("AWS_PROFILE"))
    param=cfg.GEMINI_PARAM_NAME
    original=aws.ssm.get_parameter(Name=param,WithDecryption=True)['Parameter']['Value']
    url=f'http://{cfg.stack_outputs()["ALB_DNS_NAME"]}:{cfg.ADVISOR_LISTENER_PORT}/advice?zip=60616'
    try:
        aws.ssm.put_parameter(Name=param,Type='SecureString',Value='not-a-real-key',Overwrite=True)
        print('Replaced the secret temporarily with an invalid key using Python. Value not shown.',flush=True)
        print('Allowing the advisor key cache to expire...',flush=True)
        time.sleep(int(cfg.KEY_CACHE_SECONDS)+10)
        for i in range(3):
            response=requests.get(url,timeout=40)
            body=response.json()
            print(f'Request {i+1}: HTTP {response.status_code} source={body.get("source")} advice={body.get("advice")}')
            if response.status_code!=200 or body.get('source')!='fallback':
                raise AssertionError('Expected a labelled fallback response during Gemini error')
    finally:
        aws.ssm.put_parameter(Name=param,Type='SecureString',Value=original,Overwrite=True)
        del original
        print('Original Gemini key restored by Python, even if the experiment failed.',flush=True)
    time.sleep(int(cfg.KEY_CACHE_SECONDS)+10)
    response=requests.get(url,timeout=40)
    print('After restore: HTTP',response.status_code,'source',response.json().get('source'))
    print('For evidence, capture advisor journal lines containing gemini_error via SSH.')

if __name__=='__main__':main()
