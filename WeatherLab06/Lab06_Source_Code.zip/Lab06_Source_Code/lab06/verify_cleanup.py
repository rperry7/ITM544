"""Report lab-owned AWS resources remaining after cleanup, without printing secrets."""
import json
from botocore.exceptions import ClientError
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients
from stack.weather_lab_database import database_proof
from stack.weather_lab_stack import get_alb, get_target_group


def main():
    cfg=WeatherSettings.from_file(); aws=aws_clients(cfg.region, cfg.values.get("AWS_PROFILE"))
    db=database_proof(aws,cfg)
    groups=aws.autoscaling.describe_auto_scaling_groups(
        AutoScalingGroupNames=[cfg.WEATHER_ASG_NAME,cfg.ADVISOR_ASG_NAME])['AutoScalingGroups']
    profiles=[];roles=[];templates=[];params=[]
    for role in [cfg.WEATHER_ROLE_NAME,cfg.ADVISOR_ROLE_NAME]:
        try:aws.iam.get_role(RoleName=role);roles.append(role)
        except aws.iam.exceptions.NoSuchEntityException:pass
    for lt in [cfg.WEATHER_LT_NAME,cfg.ADVISOR_LT_NAME]:
        try:aws.ec2.describe_launch_templates(LaunchTemplateNames=[lt]);templates.append(lt)
        except ClientError as e:
            if e.response['Error']['Code']!='InvalidLaunchTemplateName.NotFoundException':raise
    for p in [cfg.DB_PASSWORD_PARAM,cfg.GEMINI_PARAM_NAME]:
        try:aws.ssm.get_parameter(Name=p);params.append(p)
        except aws.ssm.exceptions.ParameterNotFound:pass
    remaining={'database':db,'alb':bool(get_alb(aws,cfg.ALB_NAME)),
        'target_groups':[tg for tg in (cfg.WEATHER_TG_NAME,cfg.ADVISOR_TG_NAME) if get_target_group(aws,tg)],
        'auto_scaling_groups':[x['AutoScalingGroupName'] for x in groups],
        'launch_templates':templates,'lab_roles':roles,'lab_parameters':params}
    print(json.dumps(remaining,indent=2))
    clean=(db['instance'] is None and not db['snapshots'] and not db['automated_backups']
           and not remaining['alb'] and not remaining['target_groups'] and not groups
           and not templates and not roles and not params)
    print('CLEANUP VERIFIED' if clean else 'CLEANUP INCOMPLETE: investigate resources above')
    if not clean:raise SystemExit(1)

if __name__=='__main__':main()
