"""Store, intentionally corrupt, restore or delete the Gemini SecureString via Python."""
import argparse
import getpass
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--delete',action='store_true',help='Delete the SSM copy during final cleanup')
    args=p.parse_args()
    cfg=WeatherSettings.from_file()
    ssm=aws_clients(cfg.region, cfg.values.get("AWS_PROFILE")).ssm
    if args.delete:
        ssm.delete_parameter(Name=cfg.GEMINI_PARAM_NAME)
        print('SSM Gemini parameter deleted. Revoke the original key in Google AI Studio as well.')
    else:
        key=getpass.getpass('Paste Gemini API key (hidden): ').strip()
        if not key or '\n' in key:raise ValueError('Invalid empty API key')
        ssm.put_parameter(Name=cfg.GEMINI_PARAM_NAME,Type='SecureString',Value=key,Overwrite=True)
        del key
        print('Gemini API key stored in SSM SecureString (value never displayed).')

if __name__=='__main__':main()
