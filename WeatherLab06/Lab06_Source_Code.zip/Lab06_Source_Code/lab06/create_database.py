"""Create the private PostgreSQL database with a random SSM-stored password."""
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients
from stack.weather_lab_database import ensure_database

if __name__ == '__main__':
    cfg=WeatherSettings.from_file()
    print('Creating/checking PostgreSQL (no credentials will be displayed)...',flush=True)
    out=ensure_database(aws_clients(cfg.region, cfg.values.get("AWS_PROFILE")),cfg)
    print('Database ready at:',out['DB_HOST'])
    print('Evidence: database configuration is private, encrypted, single-AZ and backup retention 0.')
