"""Two-tier ALB/EC2/IAM Auto Scaling stack lifecycle using only boto3."""
import base64
import json
import time
from botocore.exceptions import ClientError
from .policies import trust_policy  # Extend the original Lab 05 IAM policy helpers
from .weather_lab_common import (error_code, network_ids, security_group_id,
    ensure_security_group, ensure_ingress, revoke_ingress, delete_security_group,
    optional_call)
from .weather_lab_config import write_env


def secret_policy(account,region,param):
    """Return an exact-resource GetParameter-only inline policy."""
    arn=f'arn:aws:ssm:{region}:{account}:parameter{param}'
    return {'Version':'2012-10-17','Statement':[{'Effect':'Allow','Action':['ssm:GetParameter'],'Resource':arn}]}


def ensure_role(aws,role,profile,policy):
    """Create an EC2 service role, attach exactly one secret and an instance profile."""
    if not optional_call(lambda:aws.iam.get_role(RoleName=role),('NoSuchEntity',)):
        try:aws.iam.create_role(RoleName=role,AssumeRolePolicyDocument=json.dumps(trust_policy()))
        except ClientError as exc:
            if error_code(exc)!='EntityAlreadyExists':raise
    if not optional_call(lambda:aws.iam.get_instance_profile(InstanceProfileName=profile),('NoSuchEntity',)):
        try:aws.iam.create_instance_profile(InstanceProfileName=profile)
        except ClientError as exc:
            if error_code(exc)!='EntityAlreadyExists':raise
    current=aws.iam.get_instance_profile(InstanceProfileName=profile)['InstanceProfile']
    if role not in [r['RoleName'] for r in current.get('Roles',[])]:
        try:aws.iam.add_role_to_instance_profile(InstanceProfileName=profile,RoleName=role)
        except ClientError as exc:
            if error_code(exc)!='LimitExceeded':raise
    aws.iam.put_role_policy(RoleName=role,PolicyName=role+'-policy',PolicyDocument=json.dumps(policy))


def get_target_group(aws,name):
    """Get a target group ARN, or None when absent."""
    r=optional_call(lambda:aws.elbv2.describe_target_groups(Names=[name]),('TargetGroupNotFound',))
    return r['TargetGroups'][0]['TargetGroupArn'] if r and r['TargetGroups'] else None


def ensure_target_group(aws,name,vpc):
    """Make one HTTP:3000 target group with root health checks."""
    arn=get_target_group(aws,name)
    if arn:return arn
    return aws.elbv2.create_target_group(Name=name,Protocol='HTTP',Port=3000,
        VpcId=vpc,TargetType='instance',HealthCheckProtocol='HTTP',HealthCheckPath='/',
        HealthCheckIntervalSeconds=10,HealthCheckTimeoutSeconds=5,
        HealthyThresholdCount=2,UnhealthyThresholdCount=2)['TargetGroups'][0]['TargetGroupArn']


def get_alb(aws,name):
    """Return the existing load balancer or None."""
    r=optional_call(lambda:aws.elbv2.describe_load_balancers(Names=[name]),('LoadBalancerNotFound',))
    return r['LoadBalancers'][0] if r and r['LoadBalancers'] else None


def ensure_alb(aws,name,subnets,sg,wait=True):
    """Create the ALB before any instance launch template is constructed."""
    alb=get_alb(aws,name)
    if not alb:
        alb=aws.elbv2.create_load_balancer(Name=name,Subnets=subnets,SecurityGroups=[sg],
            Scheme='internet-facing',Type='application')['LoadBalancers'][0]
    if wait:
        aws.elbv2.get_waiter('load_balancer_available').wait(
            LoadBalancerArns=[alb['LoadBalancerArn']],WaiterConfig={'Delay':15,'MaxAttempts':40})
    return get_alb(aws,name) or alb


def ensure_listener(aws,alb_arn,port,tg_arn):
    """Add a forwarding listener only when the requested port is not present."""
    existing=aws.elbv2.describe_listeners(LoadBalancerArn=alb_arn).get('Listeners',[])
    if any(x['Port']==int(port) for x in existing):return
    aws.elbv2.create_listener(LoadBalancerArn=alb_arn,Protocol='HTTP',Port=int(port),
        DefaultActions=[{'Type':'forward','TargetGroupArn':tg_arn}])


def systemd_env(key,val):
    """Quote a value for systemd without allowing a newline or double quote injection."""
    val=str(val)
    if any(c in val for c in '\n\r"\\'):
        raise ValueError('Invalid special character in systemd setting '+key)
    return f'Environment="{key}={val}"'


def user_data(cfg,tier,alb_dns=None,db_host=None):
    """Embed the correct Node.js application, nonsecret settings, and boot commands."""
    if tier not in ('weather','advisor'):
        raise ValueError('Unknown tier: '+tier)
    folder=cfg.root/f'{tier}-app'
    encoded={x:base64.b64encode((folder/x).read_bytes()).decode('ascii')
             for x in ('app.js','package.json')}
    env=[systemd_env('PORT','3000'),systemd_env('AWS_REGION',cfg.AWS_REGION)]
    extra=''
    if tier=='weather':
        if not db_host:raise ValueError('A database endpoint is required for weather user-data')
        if 'replace-with-your-email' in cfg.CONTACT_EMAIL:
            raise ValueError('Set CONTACT_EMAIL to your own address in .env before deployment')
        env.extend([systemd_env('NWS_USER_AGENT',f'(itmo-444-544 weather lab, {cfg.CONTACT_EMAIL})'),
            systemd_env('DB_HOST',db_host),systemd_env('DB_NAME',cfg.DB_NAME),
            systemd_env('DB_USER',cfg.DB_USER),systemd_env('DB_PASSWORD_PARAM',cfg.DB_PASSWORD_PARAM),
            systemd_env('CACHE_SECONDS',cfg.CACHE_SECONDS)])
        extra=('dnf install -y postgresql15\n'
               'curl -fsSL --retry 2 -o /opt/app/rds-ca.pem '
               'https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem\n')
    else:
        if not alb_dns:raise ValueError('The ALB DNS name is required for advisor user-data')
        env.extend([systemd_env('WEATHER_URL',f'http://{alb_dns}:{cfg.WEATHER_LISTENER_PORT}'),
            systemd_env('GEMINI_KEY_PARAM',cfg.GEMINI_PARAM_NAME),
            systemd_env('GEMINI_MODEL',cfg.GEMINI_MODEL),
            systemd_env('KEY_CACHE_SECONDS',cfg.KEY_CACHE_SECONDS)])
    service='\n'.join(env)
    script=f'''#!/bin/bash
set -euo pipefail
dnf install -y nodejs
mkdir -p /opt/app
{extra}echo '{encoded['app.js']}' | base64 -d > /opt/app/app.js
echo '{encoded['package.json']}' | base64 -d > /opt/app/package.json
cd /opt/app
npm install --omit=dev
cat > /etc/systemd/system/{tier}.service <<'SERVICE'
[Unit]
Description=ITMO 544 {tier} application
After=network-online.target
Wants=network-online.target
[Service]
{service}
WorkingDirectory=/opt/app
ExecStart=/usr/bin/node /opt/app/app.js
Restart=always
RestartSec=3
User=ec2-user
[Install]
WantedBy=multi-user.target
SERVICE
chown -R ec2-user:ec2-user /opt/app
systemctl daemon-reload
systemctl enable {tier}.service
systemctl restart {tier}.service
'''
    if len(script.encode('utf-8'))>16384:
        raise ValueError(f'{tier} user-data too large: {len(script.encode())} bytes')
    return script


def ensure_launch_template(aws,name,profile,tag,cfg,script):
    """Create a launch template once; add a version only if configuration changes."""
    data={'ImageId':cfg.AMI_ID,'InstanceType':cfg.INSTANCE_TYPE,'KeyName':cfg.KEY_NAME,
        'SecurityGroupIds':[cfg.APP_SECURITY_GROUP_ID],
        'IamInstanceProfile':{'Name':profile},
        'UserData':base64.b64encode(script.encode('utf-8')).decode('ascii'),
        'TagSpecifications':[{'ResourceType':'instance','Tags':[{'Key':'Name','Value':tag}]}]}
    existing=optional_call(lambda:aws.ec2.describe_launch_templates(LaunchTemplateNames=[name]),
                           ('InvalidLaunchTemplateName.NotFoundException',))
    if not existing:
        aws.ec2.create_launch_template(LaunchTemplateName=name,LaunchTemplateData=data)
        return
    template=existing['LaunchTemplates'][0]
    latest=aws.ec2.describe_launch_template_versions(LaunchTemplateName=name,Versions=['$Latest'])['LaunchTemplateVersions'][0]
    old=latest['LaunchTemplateData']
    fields=['ImageId','InstanceType','KeyName','SecurityGroupIds','IamInstanceProfile','UserData','TagSpecifications']
    if all(old.get(x)==data[x] for x in fields):return
    new=aws.ec2.create_launch_template_version(LaunchTemplateName=name,
        SourceVersion=str(latest['VersionNumber']),LaunchTemplateData=data)
    aws.ec2.modify_launch_template(LaunchTemplateName=name,
        DefaultVersion=str(new['LaunchTemplateVersion']['VersionNumber']))


def ensure_asg(aws,name,lt,tg,tag,subnets):
    """Create one desired instance per tier, or preserve the existing group."""
    groups=aws.autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[name])['AutoScalingGroups']
    if groups:return
    aws.autoscaling.create_auto_scaling_group(AutoScalingGroupName=name,
        LaunchTemplate={'LaunchTemplateName':lt,'Version':'$Latest'},
        MinSize=1,MaxSize=1,DesiredCapacity=1,VPCZoneIdentifier=','.join(subnets),
        TargetGroupARNs=[tg],HealthCheckType='ELB',HealthCheckGracePeriod=120,
        Tags=[{'ResourceId':name,'ResourceType':'auto-scaling-group','Key':'Name',
               'Value':tag,'PropagateAtLaunch':True}])


def create_weather_stack(aws,cfg,wait=True,sleep=time.sleep):
    """Build the complete two-tier AWS stack; all resources are named/idempotent."""
    if not optional_call(lambda:aws.ssm.get_parameter(Name=cfg.GEMINI_PARAM_NAME),('ParameterNotFound',)):
        raise ValueError('Gemini key not in SSM. Run python set_gemini_key.py first.')
    db=cfg.db_outputs()
    if not db.get('DB_HOST'):
        raise ValueError('Database endpoint missing. Complete python create_database.py first.')
    acct=aws.sts.get_caller_identity()['Account']
    ensure_role(aws,cfg.WEATHER_ROLE_NAME,cfg.WEATHER_PROFILE_NAME,
                secret_policy(acct,cfg.region,cfg.DB_PASSWORD_PARAM))
    ensure_role(aws,cfg.ADVISOR_ROLE_NAME,cfg.ADVISOR_PROFILE_NAME,
                secret_policy(acct,cfg.region,cfg.GEMINI_PARAM_NAME))
    if wait:sleep(15)  # newly created IAM roles need time to propagate
    vpc,subnets=network_ids(aws,cfg)
    alb_sg=ensure_security_group(aws,vpc,cfg.ALB_SG_NAME,'Public weather advisor ALB')
    for port in (cfg.WEATHER_LISTENER_PORT,cfg.ADVISOR_LISTENER_PORT):
        ensure_ingress(aws,alb_sg,'tcp',port,cidr='0.0.0.0/0')
    revoke_ingress(aws,cfg.APP_SECURITY_GROUP_ID,'tcp',3000,cidr='0.0.0.0/0')
    ensure_ingress(aws,cfg.APP_SECURITY_GROUP_ID,'tcp',3000,source_group=alb_sg)
    w_tg=ensure_target_group(aws,cfg.WEATHER_TG_NAME,vpc)
    a_tg=ensure_target_group(aws,cfg.ADVISOR_TG_NAME,vpc)
    alb=ensure_alb(aws,cfg.ALB_NAME,subnets,alb_sg,wait=wait)
    ensure_listener(aws,alb['LoadBalancerArn'],cfg.WEATHER_LISTENER_PORT,w_tg)
    ensure_listener(aws,alb['LoadBalancerArn'],cfg.ADVISOR_LISTENER_PORT,a_tg)
    dns=alb['DNSName']
    # These must happen after the load balancer: user-data requires its DNS.
    w_data=user_data(cfg,'weather',db_host=db['DB_HOST'])
    a_data=user_data(cfg,'advisor',alb_dns=dns)
    ensure_launch_template(aws,cfg.WEATHER_LT_NAME,cfg.WEATHER_PROFILE_NAME,'weather-app',cfg,w_data)
    ensure_launch_template(aws,cfg.ADVISOR_LT_NAME,cfg.ADVISOR_PROFILE_NAME,'advisor-app',cfg,a_data)
    ensure_asg(aws,cfg.WEATHER_ASG_NAME,cfg.WEATHER_LT_NAME,w_tg,'weather-app',subnets)
    ensure_asg(aws,cfg.ADVISOR_ASG_NAME,cfg.ADVISOR_LT_NAME,a_tg,'advisor-app',subnets)
    outputs={'VPC_ID':vpc,'SUBNET_A':subnets[0],'SUBNET_B':subnets[1],
        'ALB_SECURITY_GROUP_ID':alb_sg,'ALB_ARN':alb['LoadBalancerArn'],
        'ALB_DNS_NAME':dns,'WEATHER_TG_ARN':w_tg,'ADVISOR_TG_ARN':a_tg}
    write_env(cfg.root/'stack_outputs.env',outputs)
    return outputs


def delete_asg(aws,name,sleep=time.sleep,wait=True):
    """Force-remove an ASG and wait for its instances to be terminated."""
    groups=aws.autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[name])['AutoScalingGroups']
    if not groups:return
    try:aws.autoscaling.delete_auto_scaling_group(AutoScalingGroupName=name,ForceDelete=True)
    except ClientError as exc:
        if error_code(exc) not in ('ValidationError','ResourceInUseFault'):raise
    if wait:
        for i in range(40):
            if not aws.autoscaling.describe_auto_scaling_groups(AutoScalingGroupNames=[name])['AutoScalingGroups']:
                break
            if i==39:raise TimeoutError('ASG still exists: '+name)
            sleep(15)


def delete_role(aws,role,profile):
    """Detach the instance role and delete the one inline policy and profile."""
    for call in (
        lambda:aws.iam.remove_role_from_instance_profile(InstanceProfileName=profile,RoleName=role),
        lambda:aws.iam.delete_instance_profile(InstanceProfileName=profile),
        lambda:aws.iam.delete_role_policy(RoleName=role,PolicyName=role+'-policy'),
        lambda:aws.iam.delete_role(RoleName=role)):
        optional_call(call,('NoSuchEntity',))


def delete_weather_stack(aws,cfg,wait=True,sleep=time.sleep):
    """Remove instances before ALB, target groups, security group, templates and IAM."""
    for name in (cfg.WEATHER_ASG_NAME,cfg.ADVISOR_ASG_NAME):
        delete_asg(aws,name,sleep=sleep,wait=wait)
    alb=get_alb(aws,cfg.ALB_NAME)
    if alb:
        aws.elbv2.delete_load_balancer(LoadBalancerArn=alb['LoadBalancerArn'])
        if wait:
            aws.elbv2.get_waiter('load_balancers_deleted').wait(
                LoadBalancerArns=[alb['LoadBalancerArn']],WaiterConfig={'Delay':15,'MaxAttempts':40})
    for tg in (cfg.WEATHER_TG_NAME,cfg.ADVISOR_TG_NAME):
        arn=get_target_group(aws,tg)
        if arn:
            try:aws.elbv2.delete_target_group(TargetGroupArn=arn)
            except ClientError as exc:
                if error_code(exc)!='TargetGroupNotFound':raise
    vpc,_=network_ids(aws,cfg)
    sg=security_group_id(aws,vpc,cfg.ALB_SG_NAME)
    if sg:
        revoke_ingress(aws,cfg.APP_SECURITY_GROUP_ID,'tcp',3000,source_group=sg)
    # Restore the original lab's rule as the instructor requires. Later secure it again if not using old labs.
    ensure_ingress(aws,cfg.APP_SECURITY_GROUP_ID,'tcp',3000,cidr='0.0.0.0/0')
    delete_security_group(aws,sg,sleep=sleep)
    for name in (cfg.WEATHER_LT_NAME,cfg.ADVISOR_LT_NAME):
        optional_call(lambda n=name:aws.ec2.delete_launch_template(LaunchTemplateName=n),
                      ('InvalidLaunchTemplateName.NotFoundException',))
    for role,profile in ((cfg.WEATHER_ROLE_NAME,cfg.WEATHER_PROFILE_NAME),
                         (cfg.ADVISOR_ROLE_NAME,cfg.ADVISOR_PROFILE_NAME)):
        delete_role(aws,role,profile)
    (cfg.root/'stack_outputs.env').unlink(missing_ok=True)
    return True
