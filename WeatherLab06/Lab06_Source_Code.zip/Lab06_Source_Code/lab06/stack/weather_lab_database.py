"""Idempotent RDS/SSM/EC2 database lifecycle for Lab 06."""
import secrets
import time
from botocore.exceptions import ClientError
from .weather_lab_common import (
    error_code, network_ids, security_group_id, ensure_security_group,
    ensure_ingress, delete_security_group, optional_call)
from .weather_lab_config import write_env


def database_exists(aws, cfg):
    """Return current DB metadata or None when no instance exists."""
    result=optional_call(lambda: aws.rds.describe_db_instances(DBInstanceIdentifier=cfg.DB_INSTANCE_ID),
                         ('DBInstanceNotFound','DBInstanceNotFoundFault'))
    return result['DBInstances'][0] if result else None


def ensure_database(aws, cfg, wait=True):
    """Create a private encrypted single-AZ DB with no backups and a scoped password."""
    vpc_id,subnets=network_ids(aws,cfg)
    sg=ensure_security_group(aws,vpc_id,cfg.DB_SG_NAME,'Weather database port 5432: app security group only')
    ensure_ingress(aws,sg,'tcp',5432,source_group=cfg.APP_SECURITY_GROUP_ID)
    try:
        aws.rds.create_db_subnet_group(DBSubnetGroupName=cfg.DB_SUBNET_GROUP_NAME,
            DBSubnetGroupDescription='Two-AZ subnet group for weather lab',SubnetIds=subnets)
    except ClientError as exc:
        if error_code(exc) not in ('DBSubnetGroupAlreadyExists','DBSubnetGroupAlreadyExistsFault'):raise
    # Do not overwrite a password when re-running an idempotent create.
    missing=optional_call(lambda: aws.ssm.get_parameter(Name=cfg.DB_PASSWORD_PARAM), ('ParameterNotFound',)) is None
    if missing:
        aws.ssm.put_parameter(Name=cfg.DB_PASSWORD_PARAM,Type='SecureString',
                              Value=secrets.token_hex(16),Overwrite=False)
    existing=database_exists(aws,cfg)
    if not existing:
        # Secret is only held in process memory, never printed or written to a file.
        password=aws.ssm.get_parameter(Name=cfg.DB_PASSWORD_PARAM,WithDecryption=True)['Parameter']['Value']
        try:
            aws.rds.create_db_instance(
                DBInstanceIdentifier=cfg.DB_INSTANCE_ID,DBInstanceClass=cfg.DB_INSTANCE_CLASS,
                Engine='postgres',AllocatedStorage=20,StorageType='gp2',
                MasterUsername=cfg.DB_USER,MasterUserPassword=password,DBName=cfg.DB_NAME,
                DBSubnetGroupName=cfg.DB_SUBNET_GROUP_NAME,VpcSecurityGroupIds=[sg],
                AvailabilityZone=cfg.AZ_A,BackupRetentionPeriod=0,MultiAZ=False,
                PubliclyAccessible=False,AutoMinorVersionUpgrade=False,
                DeletionProtection=False,StorageEncrypted=True)
        except ClientError as exc:
            if error_code(exc) not in ('DBInstanceAlreadyExists','DBInstanceAlreadyExistsFault'):raise
        finally:
            del password
    if wait:
        aws.rds.get_waiter('db_instance_available').wait(DBInstanceIdentifier=cfg.DB_INSTANCE_ID,
            WaiterConfig={'Delay':30,'MaxAttempts':80})
    info=database_exists(aws,cfg)
    if info and info.get('Endpoint',{}).get('Address'):
        outputs={'DB_HOST':info['Endpoint']['Address'],'DB_SECURITY_GROUP_ID':sg}
        write_env(cfg.root/'db_outputs.env',outputs)
        return outputs
    # moto does not always generate endpoints immediately; still retain SG for unit testing.
    return {'DB_SECURITY_GROUP_ID':sg,'DB_HOST':info.get('Endpoint',{}).get('Address','') if info else ''}


def delete_database(aws,cfg,wait=True,sleep=time.sleep):
    """Delete DB with no snapshot or retained automated backups; tolerate prior deletion."""
    existing=database_exists(aws,cfg)
    if existing:
        if existing.get('DBInstanceStatus')!='deleting':
            try:
                aws.rds.delete_db_instance(DBInstanceIdentifier=cfg.DB_INSTANCE_ID,
                    SkipFinalSnapshot=True,DeleteAutomatedBackups=True)
            except ClientError as exc:
                if error_code(exc) not in ('DBInstanceNotFound','DBInstanceNotFoundFault','InvalidDBInstanceState','InvalidDBInstanceStateFault'):raise
        if wait:
            aws.rds.get_waiter('db_instance_deleted').wait(DBInstanceIdentifier=cfg.DB_INSTANCE_ID,
                WaiterConfig={'Delay':30,'MaxAttempts':80})
    if not database_exists(aws,cfg):
        try:
            aws.rds.delete_db_subnet_group(DBSubnetGroupName=cfg.DB_SUBNET_GROUP_NAME)
        except ClientError as exc:
            if error_code(exc) not in ('DBSubnetGroupNotFoundFault','DBSubnetGroupNotFound'):raise
        vpc_id,_=network_ids(aws,cfg)
        sg=security_group_id(aws,vpc_id,cfg.DB_SG_NAME)
        delete_security_group(aws,sg,sleep=sleep)
        try:
            aws.ssm.delete_parameter(Name=cfg.DB_PASSWORD_PARAM)
        except ClientError as exc:
            if error_code(exc) not in ('ParameterNotFound',):raise
        (cfg.root/'db_outputs.env').unlink(missing_ok=True)
    return True


def database_proof(aws,cfg):
    """Summarize current DB settings and matching snapshots/backups without secrets."""
    db=database_exists(aws,cfg)
    snapshots=aws.rds.describe_db_snapshots().get('DBSnapshots',[])
    backups=aws.rds.describe_db_instance_automated_backups().get('DBInstanceAutomatedBackups',[])
    return {'instance':None if not db else {
        k:db.get(k) for k in ('DBInstanceIdentifier','DBInstanceClass','Engine','MultiAZ',
            'PubliclyAccessible','StorageEncrypted','BackupRetentionPeriod')},
        'snapshots':[x.get('DBSnapshotIdentifier') for x in snapshots if x.get('DBInstanceIdentifier')==cfg.DB_INSTANCE_ID],
        'automated_backups':[x.get('DBInstanceIdentifier') for x in backups if x.get('DBInstanceIdentifier')==cfg.DB_INSTANCE_ID]}
