"""Cloud weather advisor infrastructure helpers."""
