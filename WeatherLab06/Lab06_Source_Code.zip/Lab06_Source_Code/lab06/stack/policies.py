"""IAM policies as pure Python dictionaries, so tests can inspect them."""
from __future__ import annotations

OBJECT_KEY = "shared.txt"


def trust_policy() -> dict:
    """Only EC2 can assume the app roles."""
    return {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "ec2.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }],
    }


def uploader_policy(bucket: str) -> dict:
    """May upload exactly one object; no other actions."""
    return {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": ["s3:PutObject"],
            "Resource": f"arn:aws:s3:::{bucket}/{OBJECT_KEY}",
        }],
    }


def viewer_policy(bucket: str) -> dict:
    """May read shared.txt and list its bucket, but cannot write."""
    return {
        "Version": "2012-10-17",
        "Statement": [
            {"Effect": "Allow", "Action": ["s3:GetObject"],
             "Resource": f"arn:aws:s3:::{bucket}/{OBJECT_KEY}"},
            {"Effect": "Allow", "Action": ["s3:ListBucket"],
             "Resource": f"arn:aws:s3:::{bucket}"},
        ],
    }


def policy_for(tier_name: str, bucket: str) -> dict:
    return {"uploader": uploader_policy, "viewer": viewer_policy}[tier_name](bucket)
