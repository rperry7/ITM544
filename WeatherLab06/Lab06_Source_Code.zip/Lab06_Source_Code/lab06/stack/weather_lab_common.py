"""Small boto3 helpers shared by the Lab 06 database and web stack."""
import time
from dataclasses import dataclass
import boto3
from botocore.exceptions import ClientError
from .util import error_code  # Reuse the Lab 05 scoped AWS error parser
from .network import default_vpc_id, subnet_in_az  # Reuse Lab 05 VPC discovery


def optional_call(call, missing):
    """Return None only for expected not-found AWS errors."""
    try:
        return call()
    except ClientError as exc:
        if error_code(exc) in set(missing):
            return None
        raise


def aws_clients(region, profile_name=None):
    """Make real clients using the configured AWS CLI profile and region."""
    kwargs = {"region_name": region}
    if profile_name:
        kwargs["profile_name"] = profile_name
    session = boto3.session.Session(**kwargs)
    return Clients(
        ec2=session.client('ec2'), rds=session.client('rds'),
        ssm=session.client('ssm'), iam=session.client('iam'),
        elbv2=session.client('elbv2'), autoscaling=session.client('autoscaling'),
        sts=session.client('sts'))


@dataclass
class Clients:
    ec2: object
    rds: object
    ssm: object
    iam: object
    elbv2: object
    autoscaling: object
    sts: object


def network_ids(aws, cfg):
    """Reuse Lab 05's VPC and AZ subnet lookup functions for Lab 06."""
    vpc_id = default_vpc_id(aws)
    return vpc_id, [subnet_in_az(aws, vpc_id, az) for az in (cfg.AZ_A, cfg.AZ_B)]


def security_group_id(aws, vpc_id, name):
    """Look up a security group in the specified VPC by its group name."""
    groups=aws.ec2.describe_security_groups(Filters=[
        {'Name':'vpc-id','Values':[vpc_id]}, {'Name':'group-name','Values':[name]}])['SecurityGroups']
    return groups[0]['GroupId'] if groups else None


def ensure_security_group(aws, vpc_id, name, description):
    """Create once, handling a concurrent creation without a duplicate."""
    found=security_group_id(aws,vpc_id,name)
    if found:return found
    try:
        return aws.ec2.create_security_group(GroupName=name,Description=description,VpcId=vpc_id)['GroupId']
    except ClientError as exc:
        if error_code(exc)=='InvalidGroup.Duplicate':
            return security_group_id(aws,vpc_id,name)
        raise


def _ingress_permissions(protocol, port, source_group=None, cidr=None):
    """Build the EC2 IpPermissions shape accepted by boto3 for a source SG or CIDR."""
    if (source_group is None) == (cidr is None):
        raise ValueError('Choose either a source security group or a CIDR')
    permission = {
        'IpProtocol': protocol,
        'FromPort': int(port),
        'ToPort': int(port),
    }
    if source_group is not None:
        permission['UserIdGroupPairs'] = [{'GroupId': source_group}]
    else:
        permission['IpRanges'] = [{'CidrIp': cidr}]
    return [permission]


def ensure_ingress(aws, group_id, protocol, port, source_group=None, cidr=None):
    """Permit exactly one new source, ignoring already-permitted rules."""
    kwargs = {'GroupId': group_id, 'IpPermissions': _ingress_permissions(
        protocol, port, source_group=source_group, cidr=cidr)}
    try:
        aws.ec2.authorize_security_group_ingress(**kwargs)
    except ClientError as exc:
        if error_code(exc) != 'InvalidPermission.Duplicate':
            raise


def revoke_ingress(aws, group_id, protocol, port, source_group=None, cidr=None):
    """Remove an ingress rule; absence is already the desired state."""
    kwargs = {'GroupId': group_id, 'IpPermissions': _ingress_permissions(
        protocol, port, source_group=source_group, cidr=cidr)}
    try:
        aws.ec2.revoke_security_group_ingress(**kwargs)
    except ClientError as exc:
        if error_code(exc) not in ('InvalidPermission.NotFound', 'InvalidGroup.NotFound'):
            raise


def delete_security_group(aws, group_id, sleep=time.sleep):
    """Retry while released network interfaces still reference the group."""
    if not group_id:return
    for attempt in range(15):
        try:
            aws.ec2.delete_security_group(GroupId=group_id)
            return
        except ClientError as exc:
            code=error_code(exc)
            if code=='InvalidGroup.NotFound':return
            if code not in ('DependencyViolation','InvalidGroup.InUse'):raise
            if attempt==14:raise
            sleep(12)
