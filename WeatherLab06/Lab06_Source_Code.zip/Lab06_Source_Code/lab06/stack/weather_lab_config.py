"""Configuration extension for Lab 06; keep the existing Lab 05 stack package."""
from dataclasses import dataclass
from pathlib import Path

NEW_DEFAULTS = {
    "WEATHER_ROLE_NAME": "itmo-444-544-weather-role",
    "WEATHER_PROFILE_NAME": "itmo-444-544-weather-profile",
    "WEATHER_LT_NAME": "itmo-444-544-weather-lt",
    "WEATHER_TG_NAME": "itmo-444-544-weather-tg",
    "WEATHER_ASG_NAME": "itmo-444-544-weather-asg",
    "WEATHER_LISTENER_PORT": "8080",
    "ADVISOR_ROLE_NAME": "itmo-444-544-advisor-role",
    "ADVISOR_PROFILE_NAME": "itmo-444-544-advisor-profile",
    "ADVISOR_LT_NAME": "itmo-444-544-advisor-lt",
    "ADVISOR_TG_NAME": "itmo-444-544-advisor-tg",
    "ADVISOR_ASG_NAME": "itmo-444-544-advisor-asg",
    "ADVISOR_LISTENER_PORT": "8081",
    "ALB_NAME": "itmo-444-544-weather-alb",
    "ALB_SG_NAME": "itmo-444-544-weather-alb-sg",
    "DB_INSTANCE_ID": "itmo-444-544-weather-db",
    "DB_INSTANCE_CLASS": "db.t4g.micro",
    "DB_NAME": "weather",
    "DB_USER": "weatherapp",
    "DB_SG_NAME": "itmo-444-544-weather-db-sg",
    "DB_SUBNET_GROUP_NAME": "itmo-444-544-weather-db-subnets",
    "DB_PASSWORD_PARAM": "/itmo-444-544/db-password",
    "CACHE_SECONDS": "600",
    "GEMINI_PARAM_NAME": "/itmo-444-544/gemini-api-key",
    "GEMINI_MODEL": "gemini-3.1-flash-lite",
    "KEY_CACHE_SECONDS": "60",
    "CONTACT_EMAIL": "replace-with-your-email@example.com",
}
BASE_REQUIRED = ("AWS_REGION", "AZ_A", "AZ_B", "AMI_ID", "INSTANCE_TYPE", "KEY_NAME", "APP_SECURITY_GROUP_ID")


def read_env(path):
    """Read simple KEY=VALUE .env entries without shell evaluation or logging."""
    values = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, val = line.split("=", 1)
            values[key.strip()] = val.strip().strip('"').strip("'")
    return values


def write_env(path, mapping):
    """Write nonsecret runtime output to an env file."""
    Path(path).write_text("".join(f"{k}={v}\n" for k, v in mapping.items()), encoding="utf-8")


@dataclass(frozen=True)
class WeatherSettings:
    """Immutable, validated Lab 06 settings loaded from the copied .env file."""
    values: dict
    root: Path

    @classmethod
    def from_file(cls, path=".env"):
        p = Path(path).resolve()
        if not p.exists():
            raise ValueError(f"Missing {p}. First copy Lab 05 into Lab 06 and run prepare_lab06.py.")
        return cls.from_values(read_env(p), root=p.parent)

    @classmethod
    def from_values(cls, values, root=None):
        merged = {**NEW_DEFAULTS, **values}
        missing = [k for k in BASE_REQUIRED if not merged.get(k)]
        if missing:
            raise ValueError("Missing .env settings: " + ", ".join(missing))
        if merged["AZ_A"] == merged["AZ_B"]:
            raise ValueError("AZ_A and AZ_B must be different availability zones")
        for name in ("WEATHER_LISTENER_PORT", "ADVISOR_LISTENER_PORT", "CACHE_SECONDS", "KEY_CACHE_SECONDS"):
            try:
                if int(merged[name]) <= 0:
                    raise ValueError
            except ValueError:
                raise ValueError(f"{name} must be a positive integer") from None
        if not merged["CONTACT_EMAIL"] or "replace-with-your-email" in merged["CONTACT_EMAIL"]:
            # The user can run offline tests before supplying contact email.
            pass
        return cls(merged, Path(root or ".").resolve())

    def __getattr__(self, key):
        if key in self.values:
            return self.values[key]
        raise AttributeError(key)

    @property
    def region(self):
        return self.AWS_REGION

    def db_outputs(self):
        """Load the nonsecret database endpoint created by Python."""
        path = self.root / "db_outputs.env"
        if not path.exists():
            raise FileNotFoundError("db_outputs.env missing: run python create_database.py first")
        return read_env(path)

    def stack_outputs(self):
        """Load the nonsecret ALB and target group details created by Python."""
        path = self.root / "stack_outputs.env"
        if not path.exists():
            raise FileNotFoundError("stack_outputs.env missing: run python create_weather_stack.py first")
        return read_env(path)
