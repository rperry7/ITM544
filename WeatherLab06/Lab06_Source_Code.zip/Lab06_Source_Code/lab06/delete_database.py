"""Permanently delete the weather RDS instance without snapshots or backups."""
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients
from stack.weather_lab_database import delete_database

if __name__ == '__main__':
    cfg=WeatherSettings.from_file()
    print('Deleting database without retaining backups or final snapshots...',flush=True)
    delete_database(aws_clients(cfg.region, cfg.values.get("AWS_PROFILE")),cfg)
    print('Database removed. Run python verify_cleanup.py to prove deletion.')
