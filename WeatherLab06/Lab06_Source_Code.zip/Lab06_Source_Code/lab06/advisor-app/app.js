'use strict';
const express=require('express');
const {SSMClient,GetParameterCommand}=require('@aws-sdk/client-ssm');
const app=express();
const PORT=Number(process.env.PORT||3000);
const WEATHER_URL=process.env.WEATHER_URL;
const GEMINI_API_BASE=process.env.GEMINI_API_BASE||'https://generativelanguage.googleapis.com';
const GEMINI_MODEL=process.env.GEMINI_MODEL||'gemini-3.1-flash-lite';
const KEY_PARAM=process.env.GEMINI_KEY_PARAM||'/itmo-444-544/gemini-api-key';
const KEY_CACHE_MS=Number(process.env.KEY_CACHE_SECONDS||60)*1000;
const ssm=new SSMClient({region:process.env.AWS_REGION});
let cachedKey={value:null,at:0};
const log=(event,fields={})=>console.log(JSON.stringify({ts:new Date().toISOString(),event,...fields}));
async function getApiKey(){
  if(process.env.GEMINI_API_KEY) return process.env.GEMINI_API_KEY;
  if(cachedKey.value && Date.now()-cachedKey.at<KEY_CACHE_MS) return cachedKey.value;
  const out=await ssm.send(new GetParameterCommand({Name:KEY_PARAM,WithDecryption:true}));
  cachedKey={value:out.Parameter.Value,at:Date.now()};return cachedKey.value;
}
function buildPrompt(w){const f=w.forecast;return [
  `Zip code: ${w.zip} (${w.city}, ${w.state})`,`Period: ${f.name}`,
  `Temperature: ${f.temperature} ${f.temperatureUnit}`,
  `Conditions: ${f.shortForecast}`,`Wind: ${f.windSpeed}`,
  `Chance of precipitation: ${f.precipitationChance===null?'unknown':f.precipitationChance+' percent'}`
].join('\n');}
async function askGemini(prompt){
  const key=await getApiKey();
  const r=await fetch(`${GEMINI_API_BASE}/v1beta/models/${GEMINI_MODEL}:generateContent`,{
    method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},
    body:JSON.stringify({
      systemInstruction:{parts:[{text:'Give a short clothing suggestion. Reply in at most two plain sentences, with no markdown or lists. Use only the forecast given.'}]},
      contents:[{parts:[{text:prompt}]}],generationConfig:{maxOutputTokens:300}}),
    signal:AbortSignal.timeout(15000)
  });
  if(!r.ok){const e=new Error('gemini_http_error');e.status=r.status;throw e;}
  const data=await r.json();
  const text=(data.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();
  if(!text) throw new Error('gemini_empty_response');
  return text;
}
function fallbackAdvice(f){
  const t=f.temperature;
  let base=t<=32?'Wear a heavy coat, a hat and gloves.':
    t<=50?'Wear a warm jacket and long pants.':
    t<=68?'Wear a light jacket or a sweater over long sleeves.':
    t<=80?'A t-shirt and light pants or shorts will be fine.':
    'Wear light, breathable clothes and bring water and sunscreen.';
  const wet=(f.precipitationChance||0)>=40||/rain|shower|storm|snow/i.test(f.shortForecast);
  return wet?`${base} Bring an umbrella or a waterproof jacket.`:base;
}
const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function getAdvice(zip){
  if(!/^\d{5}$/.test(zip)) return {status:400,body:{error:'invalid_zip',message:'Give a 5 digit US zip code.'}};
  const started=Date.now();log('advice_request',{zip});
  let weather;
  try{
    const r=await fetch(`${WEATHER_URL}/weather?zip=${zip}`,{signal:AbortSignal.timeout(20000)});
    if(r.status===400||r.status===404) return {status:r.status,body:await r.json()};
    if(!r.ok) throw new Error('weather_status_'+r.status);
    weather=await r.json();
  }catch(e){log('weather_call_failed',{zip,message:e.message});return {status:502,body:{error:'weather_service_unavailable'}};}
  let advice,source;
  try{advice=await askGemini(buildPrompt(weather));source='gemini';}
  catch(e){log('gemini_error',{zip,status:e.status||0,reason:e.message});
    advice=fallbackAdvice(weather.forecast);source='fallback';}
  log('advice_success',{zip,source,ms:Date.now()-started});
  return {status:200,body:{...weather,advice,source,model:source==='gemini'?GEMINI_MODEL:null}};
}
app.get('/advice',async(req,res)=>{const r=await getAdvice(String(req.query.zip||''));res.status(r.status).json(r.body);});
app.get('/',async(req,res)=>{
  const form=`<form method="GET" action="/"><label>US ZIP code <input name="zip" pattern="[0-9]{5}" maxlength="5" required></label> <button type="submit">What should I wear?</button></form>`;
  let result='';
  if(req.query.zip){
    const r=await getAdvice(String(req.query.zip));
    if(r.status===200){const w=r.body,f=w.forecast;
      result=`<h2>${escapeHtml(w.city)}, ${escapeHtml(w.state)} ${escapeHtml(w.zip)}</h2>
        <p>${escapeHtml(f.name)}: ${escapeHtml(f.temperature)} ${escapeHtml(f.temperatureUnit)}, ${escapeHtml(f.shortForecast)}, wind ${escapeHtml(f.windSpeed)}</p>
        <p><strong>${escapeHtml(w.advice)}</strong></p>
        <p><small>Suggestion source: ${escapeHtml(w.source)}</small></p>`;
    }else result=`<p>Sorry: ${escapeHtml(r.body.error)}</p>`;
  }
  res.status(200).send(`<h1>Weather Advisor</h1>${form}${result}`);
});
app.listen(PORT,()=>log('advisor_started',{port:PORT,model:GEMINI_MODEL}));
