"""Live AWS integration tests. Run with pytest -m integration -s after deployment."""
import json
import socket
import time
import requests
import pytest
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients

pytestmark=pytest.mark.integration


@pytest.fixture(scope='module')
def deployed():
    cfg=WeatherSettings.from_file()
    aws=aws_clients(cfg.region, cfg.values.get("AWS_PROFILE"))
    out=cfg.stack_outputs()
    return cfg,aws,out


def urls(deployed):
    cfg,_,out=deployed
    host=out['ALB_DNS_NAME']
    return f'http://{host}:{cfg.WEATHER_LISTENER_PORT}',f'http://{host}:{cfg.ADVISOR_LISTENER_PORT}'


def test_both_target_groups_healthy(deployed):
    _,aws,out=deployed
    for key in ('WEATHER_TG_ARN','ADVISOR_TG_ARN'):
        states=[x['TargetHealth']['State'] for x in aws.elbv2.describe_target_health(
            TargetGroupArn=out[key])['TargetHealthDescriptions']]
        assert states and all(x=='healthy' for x in states),f'{key}: {states}'


def test_weather_cache_and_history(deployed):
    w,_=urls(deployed)
    # The first response may hit an earlier cache; the second must be a hit.
    a=requests.get(f'{w}/weather?zip=60616',timeout=35)
    b=requests.get(f'{w}/weather?zip=60616',timeout=35)
    assert a.status_code==200 and a.json().get('cache') in ('miss','hit')
    assert b.status_code==200 and b.json()['cache']=='hit'
    history=requests.get(f'{w}/history',timeout=10)
    assert history.status_code==200 and history.json()['count']>=1
    print('First cache:',a.json()['cache'],'Second cache:',b.json()['cache'],
          'Saved rows:',history.json()['count'])


def test_zip_validation(deployed):
    w,a=urls(deployed)
    assert requests.get(f'{w}/weather?zip=abc',timeout=15).status_code==400
    assert requests.get(f'{w}/weather?zip=00000',timeout=15).status_code==404
    assert requests.get(f'{a}/advice?zip=abc',timeout=15).status_code==400


def test_advisor_and_page(deployed):
    _,a=urls(deployed)
    response=requests.get(f'{a}/advice?zip=60616',timeout=40)
    assert response.status_code==200 and response.json().get('advice')
    assert response.json().get('source') in ('gemini','fallback')
    page=requests.get(a+'/',timeout=10)
    assert page.status_code==200 and '<form' in page.text
    print('Advice source:',response.json()['source'])


def reachable(host,port,timeout=4):
    try:
        with socket.create_connection((host,int(port)),timeout=timeout):return True
    except (OSError,TimeoutError):return False


def test_no_direct_app_or_db_access(deployed):
    cfg,aws,_=deployed
    w,_=urls(deployed)
    resp=aws.ec2.describe_instances(Filters=[{'Name':'tag:Name','Values':['weather-app']},
        {'Name':'instance-state-name','Values':['running']}])
    instances=[i for r in resp['Reservations'] for i in r['Instances']]
    assert instances,'No running weather EC2 instance'
    address=instances[0].get('PublicIpAddress')
    if address:assert not reachable(address,3000)
    assert requests.get(w+'/',timeout=8).status_code==200
    db_host=cfg.db_outputs()['DB_HOST']
    assert not reachable(db_host,5432)


def test_ssm_simulator_least_privilege(deployed):
    cfg,aws,_=deployed
    account=aws.sts.get_caller_identity()['Account']
    arns={key:f'arn:aws:ssm:{cfg.region}:{account}:parameter{param}' for key,param in (
        ('weather',cfg.DB_PASSWORD_PARAM),('advisor',cfg.GEMINI_PARAM_NAME))}
    for role,expected in ((cfg.WEATHER_ROLE_NAME,'weather'),(cfg.ADVISOR_ROLE_NAME,'advisor')):
        role_arn=aws.iam.get_role(RoleName=role)['Role']['Arn']
        for secret,resource in arns.items():
            decision=aws.iam.simulate_principal_policy(PolicySourceArn=role_arn,
                ActionNames=['ssm:GetParameter'],ResourceArns=[resource])['EvaluationResults'][0]['EvalDecision']
            print(role,secret,decision)
            assert decision==('allowed' if secret==expected else 'implicitDeny')


def test_rds_configuration_and_backups(deployed):
    cfg,aws,_=deployed
    from stack.weather_lab_database import database_proof
    p=database_proof(aws,cfg)
    assert p['instance'] is not None
    assert p['instance']['PubliclyAccessible'] is False
    assert p['instance']['MultiAZ'] is False
    assert p['instance']['StorageEncrypted'] is True
    assert p['instance']['BackupRetentionPeriod']==0
    assert p['snapshots']==[] and p['automated_backups']==[]
    print(json.dumps(p,indent=2))
