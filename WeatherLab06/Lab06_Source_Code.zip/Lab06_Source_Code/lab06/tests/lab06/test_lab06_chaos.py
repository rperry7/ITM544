"""Live destructive experiments. Run only while the lab stack is deployed."""
import subprocess
import time
from pathlib import Path
import pytest
import requests
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients, ensure_ingress, revoke_ingress

pytestmark=pytest.mark.chaos


@pytest.fixture(scope='module')
def live():
    cfg=WeatherSettings.from_file()
    return cfg,aws_clients(cfg.region, cfg.values.get("AWS_PROFILE")),cfg.stack_outputs(),cfg.db_outputs()


def url(live,tier):
    cfg,_,out,_=live
    return f'http://{out["ALB_DNS_NAME"]}:{cfg.WEATHER_LISTENER_PORT if tier=="weather" else cfg.ADVISOR_LISTENER_PORT}'


def instance_ip(aws,name):
    """Find the public address for one instance using its launch template Name tag."""
    r=aws.ec2.describe_instances(Filters=[{'Name':'tag:Name','Values':[name]},
        {'Name':'instance-state-name','Values':['running']}])
    ips=[x.get('PublicIpAddress') for a in r['Reservations'] for x in a['Instances']]
    return next((x for x in ips if x),None)


def restart_weather(aws,cfg):
    ip=instance_ip(aws,'weather-app')
    if not ip:pytest.skip('Weather EC2 has no SSH-reachable public IP')
    private=cfg.root/f'{cfg.KEY_NAME}.pem'
    if not private.exists():
        pytest.skip(f'Key file missing locally: {private.name}')
    subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12',
                    '-o','StrictHostKeyChecking=accept-new','-i',str(private),
                    f'ec2-user@{ip}','sudo systemctl restart weather'],check=True,timeout=45)


def test_database_outage_preserves_weather(live):
    """Revoke database permission, force a fresh pool, then restore rule in finally."""
    cfg,aws,_,db=live
    sg=db['DB_SECURITY_GROUP_ID']
    revoke_ingress(aws,sg,'tcp',5432,source_group=cfg.APP_SECURITY_GROUP_ID)
    try:
        restart_weather(aws,cfg)
        time.sleep(5)
        answer=requests.get(url(live,'weather')+'/weather?zip=60616',timeout=40)
        print('DB outage weather HTTP:',answer.status_code,'cache:',answer.json().get('cache'))
        assert answer.status_code==200 and answer.json()['cache']=='unavailable'
        history=requests.get(url(live,'weather')+'/history',timeout=15)
        assert history.status_code==503
        print('History during outage HTTP:',history.status_code)
    finally:
        ensure_ingress(aws,sg,'tcp',5432,source_group=cfg.APP_SECURITY_GROUP_ID)
        print('Database network rule restored by Python.')


def test_weather_instance_failure_recovers_within_300_seconds(live):
    """Terminate only the weather ASG instance and measure real recovery time."""
    cfg,aws,_,_=live
    groups=aws.autoscaling.describe_auto_scaling_groups(
        AutoScalingGroupNames=[cfg.WEATHER_ASG_NAME])['AutoScalingGroups']
    assert len(groups)==1 and groups[0]['Instances']
    victim=groups[0]['Instances'][0]['InstanceId']
    aws.autoscaling.terminate_instance_in_auto_scaling_group(
        InstanceId=victim,ShouldDecrementDesiredCapacity=False)
    started=time.monotonic();went_down=False;advisor_unavailable=False
    weather=url(live,'weather');advisor=url(live,'advisor')
    recovered=False
    while time.monotonic()-started<=300:
        try:
            w=requests.get(weather+'/weather?zip=60616',timeout=8)
            w_ok=w.status_code==200
        except requests.RequestException:
            w_ok=False
        if not w_ok:
            went_down=True
            try:
                a=requests.get(advisor+'/advice?zip=33101',timeout=24)
                if a.status_code==502 and a.json().get('error')=='weather_service_unavailable':
                    advisor_unavailable=True
            except requests.RequestException:pass
        if went_down and w_ok:
            recovered=True;break
        time.sleep(8)
    elapsed=round(time.monotonic()-started,1)
    print('Weather recovered:',recovered,'after',elapsed,'seconds')
    print('Saw advisor 502 during outage:',advisor_unavailable)
    assert went_down,'The outage was not observed; repeat with a longer poll window if cutover was too fast'
    assert recovered and elapsed<=300
    assert advisor_unavailable,'Advisor 502 was not captured during the short outage'
    assert requests.get(advisor+'/',timeout=10).status_code==200
