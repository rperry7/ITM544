"""Graduate-level Lab 06 unit tests. Moto: in-memory AWS; no real credentials."""
import base64
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock
import boto3
import pytest
from moto import mock_aws
from botocore.exceptions import ClientError
from stack.weather_lab_common import Clients
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_database import ensure_database, delete_database, database_proof
from stack.weather_lab_stack import (secret_policy,ensure_role,user_data,create_weather_stack)

ROOT=Path(__file__).resolve().parents[2]

@pytest.fixture
def fake_cfg(tmp_path):
    for app in ('weather-app','advisor-app'):
        (tmp_path/app).mkdir()
        for f in ('app.js','package.json'):
            (tmp_path/app/f).write_bytes((ROOT/app/f).read_bytes())
    vals={
        'AWS_REGION':'us-east-2','AZ_A':'us-east-2a','AZ_B':'us-east-2b',
        'AMI_ID':'ami-12345678','INSTANCE_TYPE':'t3.micro','KEY_NAME':'test-key',
        'APP_SECURITY_GROUP_ID':'sg-test','CONTACT_EMAIL':'test@example.com',
        'WEATHER_ROLE_NAME':'test-w-role','WEATHER_PROFILE_NAME':'test-w-profile',
        'WEATHER_LT_NAME':'test-w-lt','WEATHER_TG_NAME':'test-w-tg','WEATHER_ASG_NAME':'test-w-asg',
        'ADVISOR_ROLE_NAME':'test-a-role','ADVISOR_PROFILE_NAME':'test-a-profile',
        'ADVISOR_LT_NAME':'test-a-lt','ADVISOR_TG_NAME':'test-a-tg','ADVISOR_ASG_NAME':'test-a-asg',
        'ALB_NAME':'test-weather-alb','ALB_SG_NAME':'test-weather-alb-sg',
        'DB_INSTANCE_ID':'test-weather-db','DB_SG_NAME':'test-weather-db-sg',
        'DB_SUBNET_GROUP_NAME':'test-weather-subnets','DB_PASSWORD_PARAM':'/lab06/db-pass',
        'GEMINI_PARAM_NAME':'/lab06/gemini-key'
    }
    return WeatherSettings.from_values(vals,root=tmp_path)

@pytest.fixture
def fake_aws():
    with mock_aws():
        region='us-east-2'
        session=boto3.session.Session(region_name=region,
            aws_access_key_id='testing',aws_secret_access_key='testing')
        ec2=session.client('ec2')
        vpcs=ec2.describe_vpcs(Filters=[{'Name':'isDefault','Values':['true']}])['Vpcs']
        vpc=vpcs[0]['VpcId'] if vpcs else ec2.create_vpc(CidrBlock='10.0.0.0/16')['Vpc']['VpcId']
        if not vpcs:ec2.modify_vpc_attribute(VpcId=vpc,EnableDnsSupport={'Value':True})
        for az,i in [('us-east-2a',1),('us-east-2b',2)]:
            present=ec2.describe_subnets(Filters=[{'Name':'vpc-id','Values':[vpc]},
                {'Name':'availability-zone','Values':[az]}])['Subnets']
            if not present:ec2.create_subnet(VpcId=vpc,CidrBlock=f'10.0.{i}.0/24',AvailabilityZone=az)
        sg=ec2.create_security_group(GroupName='test-app-sg',Description='test',VpcId=vpc)['GroupId']
        aws=Clients(ec2=ec2,rds=session.client('rds'),ssm=session.client('ssm'),
            iam=session.client('iam'),elbv2=session.client('elbv2'),
            autoscaling=session.client('autoscaling'),sts=session.client('sts'))
        yield aws,sg


def cfg_with_sg(fake_cfg,sg):
    """Return a config linked to moto's actual default VPC security group ID."""
    return WeatherSettings.from_values({**fake_cfg.values,'APP_SECURITY_GROUP_ID':sg},root=fake_cfg.root)


def test_database_has_required_free_tier_properties(fake_aws,fake_cfg):
    aws,sg=fake_aws;cfg=cfg_with_sg(fake_cfg,sg)
    ensure_database(aws,cfg,wait=False)
    db=aws.rds.describe_db_instances(DBInstanceIdentifier=cfg.DB_INSTANCE_ID)['DBInstances'][0]
    assert db['DBInstanceClass']==cfg.DB_INSTANCE_CLASS=='db.t4g.micro'
    assert db['BackupRetentionPeriod']==0
    assert db['MultiAZ'] is False
    assert db['PubliclyAccessible'] is False
    assert db['StorageEncrypted'] is True
    assert db['AllocatedStorage']==20


def test_database_port_only_accepts_app_sg(fake_aws,fake_cfg):
    aws,sg=fake_aws;cfg=cfg_with_sg(fake_cfg,sg)
    output=ensure_database(aws,cfg,wait=False)
    group=aws.ec2.describe_security_groups(GroupIds=[output['DB_SECURITY_GROUP_ID']])['SecurityGroups'][0]
    tcp=[p for p in group['IpPermissions'] if p['IpProtocol']=='tcp' and p['FromPort']==5432]
    assert len(tcp)==1
    assert [x['GroupId'] for x in tcp[0]['UserIdGroupPairs']]==[sg]
    assert tcp[0].get('IpRanges',[])==[]


def test_create_then_delete_leaves_no_db_or_secret(fake_aws,fake_cfg):
    aws,sg=fake_aws;cfg=cfg_with_sg(fake_cfg,sg)
    ensure_database(aws,cfg,wait=False)
    delete_database(aws,cfg,wait=False,sleep=lambda _:None)
    assert database_proof(aws,cfg)['instance'] is None
    assert database_proof(aws,cfg)['snapshots']==[]
    with pytest.raises(aws.ssm.exceptions.ParameterNotFound):
        aws.ssm.get_parameter(Name=cfg.DB_PASSWORD_PARAM)
    delete_database(aws,cfg,wait=False,sleep=lambda _:None)


def test_database_create_twice_does_not_duplicate(fake_aws,fake_cfg):
    aws,sg=fake_aws;cfg=cfg_with_sg(fake_cfg,sg)
    ensure_database(aws,cfg,wait=False)
    secret1=aws.ssm.get_parameter(Name=cfg.DB_PASSWORD_PARAM,WithDecryption=True)['Parameter']['Value']
    ensure_database(aws,cfg,wait=False)
    secret2=aws.ssm.get_parameter(Name=cfg.DB_PASSWORD_PARAM,WithDecryption=True)['Parameter']['Value']
    assert secret1==secret2
    assert len(aws.rds.describe_db_instances(DBInstanceIdentifier=cfg.DB_INSTANCE_ID)['DBInstances'])==1


def test_roles_are_exactly_least_privilege(fake_aws,fake_cfg):
    aws,sg=fake_aws;cfg=cfg_with_sg(fake_cfg,sg)
    account=aws.sts.get_caller_identity()['Account']
    for role,profile,mine,theirs in ((cfg.WEATHER_ROLE_NAME,cfg.WEATHER_PROFILE_NAME,
            cfg.DB_PASSWORD_PARAM,cfg.GEMINI_PARAM_NAME),
            (cfg.ADVISOR_ROLE_NAME,cfg.ADVISOR_PROFILE_NAME,
            cfg.GEMINI_PARAM_NAME,cfg.DB_PASSWORD_PARAM)):
        doc=secret_policy(account,cfg.region,mine)
        assert doc['Statement'][0]['Action']==['ssm:GetParameter']
        assert doc['Statement'][0]['Resource'].endswith('parameter'+mine)
        assert theirs not in json.dumps(doc)
        ensure_role(aws,role,profile,doc)
        ensure_role(aws,role,profile,doc)
        inline=aws.iam.get_role_policy(RoleName=role,PolicyName=role+'-policy')['PolicyDocument']
        assert inline['Statement'][0]['Resource']==doc['Statement'][0]['Resource']
        assert len(aws.iam.get_instance_profile(InstanceProfileName=profile)['InstanceProfile']['Roles'])==1


def test_user_data_contains_endpoints_not_password(fake_cfg):
    weather=user_data(fake_cfg,'weather',db_host='test-db.internal')
    advisor=user_data(fake_cfg,'advisor',alb_dns='test-alb.amazonaws.com')
    assert 'test-db.internal' in weather
    assert 'test-alb.amazonaws.com' in advisor
    assert 'http://test-alb.amazonaws.com:8080' in advisor
    assert 'DB_PASSWORD_PARAM=' in weather
    assert 'DB_PASSWORD=' not in weather
    assert 'test-db.internal' not in advisor


def test_both_user_data_files_are_below_16kb(fake_cfg):
    for tier,kw in (('weather',{'db_host':'test-db.internal'}),
                    ('advisor',{'alb_dns':'example-alb.amazonaws.com'})):
        assert len(user_data(fake_cfg,tier,**kw).encode())<16384


def test_validation_rejects_same_az(fake_cfg):
    with pytest.raises(ValueError,match='different'):
        WeatherSettings.from_values({**fake_cfg.values,'AZ_B':fake_cfg.AZ_A})


def test_alb_created_before_template_and_twice_is_safe(fake_aws,fake_cfg,monkeypatch):
    """Instrument the build graph without starting actual EC2 instances."""
    import stack.weather_lab_stack as w
    aws,sg=fake_aws;cfg=cfg_with_sg(fake_cfg,sg)
    aws.ssm.put_parameter(Name=cfg.GEMINI_PARAM_NAME,Type='SecureString',Value='fake',Overwrite=True)
    (cfg.root/'db_outputs.env').write_text('DB_HOST=test-rds.internal\nDB_SECURITY_GROUP_ID=sg-fake\n')
    events=[]
    real_alb=w.ensure_alb
    real_launch=w.ensure_launch_template
    def watched_alb(*args,**kw):
        result=real_alb(*args,**kw);events.append('alb');return result
    def watched_launch(*args,**kw):
        events.append('launch');return real_launch(*args,**kw)
    monkeypatch.setattr(w,'ensure_alb',watched_alb)
    monkeypatch.setattr(w,'ensure_launch_template',watched_launch)
    monkeypatch.setattr(w,'ensure_asg',lambda *a,**k:None)
    create_weather_stack(aws,cfg,wait=False)
    create_weather_stack(aws,cfg,wait=False)
    assert events.index('alb')<events.index('launch')
    assert len(aws.elbv2.describe_load_balancers()['LoadBalancers'])==1
    assert len(aws.elbv2.describe_target_groups()['TargetGroups'])==2
    templates=aws.ec2.describe_launch_templates()['LaunchTemplates']
    assert len(templates)==2
    versions=aws.ec2.describe_launch_template_versions(
        LaunchTemplateName=cfg.ADVISOR_LT_NAME)['LaunchTemplateVersions']
    assert len(versions)==1
    advisor_data=base64.b64decode(versions[0]['LaunchTemplateData']['UserData']).decode()
    assert cfg.WEATHER_LISTENER_PORT in advisor_data
    assert 'test-rds.internal' not in advisor_data
