'use strict';
const fs = require('fs');
const express = require('express');
const { Pool } = require('pg');
const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ZIP_API = process.env.ZIP_API_BASE || 'https://api.zippopotam.us';
const NWS_API = process.env.NWS_API_BASE || 'https://api.weather.gov';
const USER_AGENT = process.env.NWS_USER_AGENT || '(itmo-444-544 weather lab, student@example.com)';
const DB_HOST = process.env.DB_HOST;
const DB_PORT = Number(process.env.DB_PORT || 5432);
const DB_NAME = process.env.DB_NAME || 'weather';
const DB_USER = process.env.DB_USER || 'weatherapp';
const DB_PASSWORD_PARAM = process.env.DB_PASSWORD_PARAM || '/itmo-444-544/db-password';
const DB_CA_FILE = process.env.DB_CA_FILE || '/opt/app/rds-ca.pem';
const CACHE_SECONDS = Number(process.env.CACHE_SECONDS || 600);
const DB_RETRY_MS = 30000;
const ssm = new SSMClient({ region: process.env.AWS_REGION });
const log = (event, fields={}) => console.log(JSON.stringify({ts:new Date().toISOString(),event,...fields}));
class UpstreamError extends Error {
  constructor(stage,status) {super(`${stage} failed`); this.stage=stage; this.status=status;}
}
async function fetchJson(stage,url,headers={}) {
  let status=0;
  for(let attempt=1;attempt<=2;attempt++) {
    try {
      const res=await fetch(url,{headers,signal:AbortSignal.timeout(8000)});
      status=res.status;
      if(res.ok) return await res.json();
      if(res.status===404) return null;
      if(res.status<500 && res.status!==429) break;
    } catch(err) {status=0;}
    if(attempt<2) await new Promise(r=>setTimeout(r,500));
  }
  throw new UpstreamError(stage,status);
}
let poolPromise=null;
let dbRetryAt=0;
async function createPool() {
  const password=process.env.DB_PASSWORD ||
    (await ssm.send(new GetParameterCommand({Name:DB_PASSWORD_PARAM,WithDecryption:true}))).Parameter.Value;
  const ssl=process.env.DB_SSL==='off'?false:{ca:fs.readFileSync(DB_CA_FILE,'utf8'),rejectUnauthorized:true};
  const pool=new Pool({host:DB_HOST,port:DB_PORT,database:DB_NAME,user:DB_USER,password,ssl,
    max:4,connectionTimeoutMillis:3000,idleTimeoutMillis:30000,statement_timeout:3000});
  pool.on('error',e=>log('db_error',{stage:'pool',message:e.message}));
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS lookups (
      id BIGSERIAL PRIMARY KEY, zip CHAR(5) NOT NULL,
      payload JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
    await pool.query('CREATE INDEX IF NOT EXISTS lookups_zip_created ON lookups (zip,created_at DESC)');
  } catch(e){await pool.end().catch(()=>{});throw e;}
  return pool;
}
function getPool(){
  if(!poolPromise) poolPromise=createPool().catch(e=>{poolPromise=null;throw e;});
  return poolPromise;
}
async function withDb(stage,fn){
  if(!DB_HOST) return {state:'disabled'};
  if(Date.now()<dbRetryAt) return {state:'unavailable'};
  try{return {state:'ok',value:await fn(await getPool())};}
  catch(e){
    dbRetryAt=Date.now()+DB_RETRY_MS;
    // Re-establish connections after network recovery, instead of reusing broken pool.
    const previous=poolPromise;poolPromise=null;
    if(previous) previous.then(p=>p.end()).catch(()=>{});
    log('db_error',{stage,message:e.message});return {state:'unavailable'};
  }
}
const findFresh=zip=>withDb('read',async pool=>{
  const r=await pool.query(`SELECT payload FROM lookups WHERE zip=$1
    AND created_at > now()-make_interval(secs=>$2)
    ORDER BY created_at DESC LIMIT 1`,[zip,CACHE_SECONDS]);
  return r.rows.length?r.rows[0].payload:null;
});
const saveLookup=(zip,payload)=>withDb('write',pool=>
  pool.query('INSERT INTO lookups (zip,payload) VALUES ($1,$2)',[zip,JSON.stringify(payload)]));
app.get('/',(req,res)=>res.json({service:'weather',usage:'/weather?zip=60616',history:'/history'}));
app.get('/history',async(req,res)=>{
  const result=await withDb('history',async pool=>{
    const r=await pool.query(`SELECT id,zip,payload->>'city' AS city,
      payload->>'state' AS state,payload->'forecast'->>'shortForecast' AS short_forecast,
      payload->'forecast'->>'temperature' AS temperature,created_at
      FROM lookups ORDER BY created_at DESC LIMIT 10`);
    return r.rows;
  });
  if(result.state==='disabled') return res.status(503).json({error:'database_disabled'});
  if(result.state==='unavailable') return res.status(503).json({error:'database_unavailable'});
  res.json({count:result.value.length,lookups:result.value});
});
app.get('/weather',async(req,res)=>{
  const zip=String(req.query.zip||'');
  if(!/^\d{5}$/.test(zip)) {
    log('weather_rejected',{reason:'invalid_zip'});
    return res.status(400).json({error:'invalid_zip',message:'Give a 5 digit US zip code.'});
  }
  const started=Date.now();log('weather_request',{zip});
  const cached=await findFresh(zip);
  if(cached.state==='ok' && cached.value){
    log('weather_success',{zip,cache:'hit',ms:Date.now()-started});
    return res.json({...cached.value,cache:'hit'});
  }
  try {
    const lookup=await fetchJson('zip_lookup',`${ZIP_API}/us/${zip}`);
    if(!lookup || !lookup.places?.length) return res.status(404).json({error:'zip_not_found'});
    const place=lookup.places[0];
    const lat=Number(place.latitude).toFixed(4),lon=Number(place.longitude).toFixed(4);
    const headers={'User-Agent':USER_AGENT,Accept:'application/geo+json'};
    const point=await fetchJson('nws_points',`${NWS_API}/points/${lat},${lon}`,headers);
    if(!point) return res.status(404).json({error:'no_nws_coverage'});
    const forecast=await fetchJson('nws_forecast',point.properties.forecast,headers);
    if(!forecast?.properties?.periods?.length) throw new UpstreamError('nws_forecast',502);
    const p=forecast.properties.periods[0];
    const body={zip,city:place['place name'],state:place['state abbreviation'],latitude:lat,longitude:lon,
      forecast:{name:p.name,temperature:p.temperature,temperatureUnit:p.temperatureUnit,
        shortForecast:p.shortForecast,windSpeed:p.windSpeed,
        precipitationChance:p.probabilityOfPrecipitation?.value??null,isDaytime:p.isDaytime}};
    const saved=await saveLookup(zip,body);
    const cache=saved.state==='ok'?'miss':saved.state;
    log('weather_success',{zip,cache,ms:Date.now()-started});
    return res.json({...body,cache});
  }catch(e){
    if(e instanceof UpstreamError){
      log('weather_error',{zip,stage:e.stage,status:e.status});
      return res.status(502).json({error:'upstream_error',stage:e.stage});
    }
    log('weather_error',{zip,stage:'internal',message:e.message});
    res.status(500).json({error:'internal_error'});
  }
});
app.listen(PORT,()=>log('weather_started',{port:PORT}));
