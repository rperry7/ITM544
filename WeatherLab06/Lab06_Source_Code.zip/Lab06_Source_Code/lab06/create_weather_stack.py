"""Create weather and advisor services, ALB, IAM roles, EC2 and Auto Scaling."""
from stack.weather_lab_config import WeatherSettings
from stack.weather_lab_common import aws_clients
from stack.weather_lab_stack import create_weather_stack

if __name__ == '__main__':
    cfg=WeatherSettings.from_file()
    print('Building weather and advisor infrastructure...',flush=True)
    out=create_weather_stack(aws_clients(cfg.region, cfg.values.get("AWS_PROFILE")),cfg)
    print('Weather:',f'http://{out["ALB_DNS_NAME"]}:{cfg.WEATHER_LISTENER_PORT}/weather?zip=60616')
    print('Advisor:',f'http://{out["ALB_DNS_NAME"]}:{cfg.ADVISOR_LISTENER_PORT}/')
    print('Instances install Node.js on first boot. Check target group health before testing.')
